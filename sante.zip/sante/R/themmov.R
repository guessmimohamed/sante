
dpm<- function() {
library(dashboardthemes)
library(shinydashboard)
library(datasets)
library(ggplot2)
library(leaflet)
library(maptools)
library(sp)
library(shapefiles)
library(raster)
library(magrittr)
library(leaflet)
library(reshape2)
library(stringdist)


source('moduleChangeTheme.R')
source('importation.R')
source('liatt.R')
rawData <- read.csv("officine.csv")


data <- rawData[, c(2, 4, 6, 9)]
colnames(data) <- c("Pharmaciste", "Gouvernorat", "Commune", "Type")

ui <- dashboardPage(


  dashboardHeader(title = "P & M ",

                  tags$li(class = "dropdown",
                          tags$a(href = "https://www.linkedin.com/in/daghbouji-mohamed-326432131/",
                                 target = "_blank",
                                 tags$img(height = "30px",
                                          src = "linkedin.png")
                          )
                  ),
                  tags$li(a(href = 'http://www.dpm.tn/',
                            img(src = 'telechargement.png',
                                title = "DPM", height = "30px")
                            ),
                          class = "dropdown"),
                  tags$li(a(actionButton(inputId = "quit",
                                         icon("power-off"),
                                         title = "Back to Apps Home",height = "30px")),
                          class = "dropdown")),

  dashboardSidebar(
    sidebarMenu(
      menuItem("Themes", tabName = "Themes", icon = icon("images")),
      menuItem("Introduction", tabName = "Introduction", icon = icon("outdent")),
      menuItem("Officine", tabName = "Officine", icon = icon("first-aid"),
               menuSubItem("base_officine", tabName = "base_officine",icon = icon("database")),
               menuSubItem("map", tabName = "map",icon = icon("globe")),
               menuSubItem("liste d'attente", tabName = "listatt",icon = icon("first-aid"))
      ),


      menuItem("Importation",tabName = "Importation",icon = icon("exchange-alt"),

               menuSubItem("graphe ", tabName = "graphe",icon = icon("chart-bar"))),

      menuItem("Contact",tabName = "Contact",icon = icon("id-card"))

    )
  ),

  dashboardBody(
    uiChangeThemeOutput(),



     tabItems(
       # Tab content -------------------------------------------------------------
       tabItem(
         tabName = "Themes",
         fluidRow(
           column(
             width = 12,

             # Theme drop-down ---------------------------------------------------------
             uiChangeThemeDropdown(dropDownLabel = "THEME ", defaultTheme = "blue_gradient")
           ))),

      # First tab content
      tabItem(tabName = "Introduction",box(title = "Introduction",
                                           status = "info",solidHeader = TRUE,collapsible = TRUE,width = 10 ,
                                           h4("La Direction de la Pharmacie et du Médicament est une unité technico-administrative du Ministère de la Santé Publique. Elle gère tous les aspects administratifs liés à la pharmacie, au médicament et activités apparentées. Elle coordonne les activités du Système National d'Assurance Qualité des Médicaments et procède au Contrôle Technique à l'Importation des médicaments, des accessoires médicaux et des produits cosmétiques à vente limitée aux pharmacies.

 La DPM assure la tutelle des organismes étatiques en matière de médicament et veille à la gestion des psychotropes et stupéfiants sur le plan national et international.

Depuis le 17 Mai 1998, elle a bénéficié du statut de Centre Collaborateur de l'O.M.S en matière d'enregistrement des médicaments et de réglementation pharmaceutique.

Elle a également reçu depuis l'année 2001 l'appui de la coopération Italienne pour renforcer ses activités.")),

              fluidRow(
                # A static infoBox
                infoBox(" 31, Rue de Khartoum 1002 ",br(),"  Tunis-Belvédère Tunisie", icon = icon("map-marker-alt"),fill=TRUE,color = "orange",width = 4),
                infoBox("Téléphone:",br()," (+216 ) 71 78 31 95 / 71 79 06 39", icon = icon("phone-volume"),fill=TRUE,color = "aqua",width = 4),
                infoBox("Email:",br()," dpm@rns.tn", icon = icon("at"),fill=TRUE,color = "navy",width = 3)

              )),
      tabItem(tabName = "map",box(title = "officine",
                                       status = "primary",solidHeader = TRUE,collapsible = TRUE,width = 12 ,
                                       h4("Liste des Officines par Gouvernorat")),



              fluidPage(
                leafletOutput("map")
              )
      ),

      tabItem(tabName ="base_officine",
              fluidPage(
                titlePanel("Basic DataTable"),

                # Create a new Row in the UI for selectInputs

                fluidRow(


                  column(4,
                         selectInput("stat",
                                     "Gouvernorat:",
                                     c("All",
                                       unique(as.character(data$Gouvernorat))))
                         )
                ),
                # Create a new row for the table.
                fluidRow(
                  DT::dataTableOutput("table")
                )
              )
      ),


      tabItem(tabName = "Contact", h4("Crée par:",br()," Guessmi Mohamed"
                                      ), fluidRow(
                                        # A static infoBox
                                        infoBox("Email", h6("
                                                            daghboujimohamed4@gmail.com"), icon = icon("credit-card"),fill=TRUE,color="red")

                                      )),
      tabItem(tabName = "graphe",

                  # Use a fluid Bootstrap layout
                  fluidPage(
                    box(title = "Quantite",
                        status = "info",solidHeader = TRUE,collapsible = TRUE,width = 6,
                        sliderInput("range", "Annees Debut-Fin:",2010 , 2019, value=c(2010,2019),width = 200),
                        plotlyOutput("plot3")

                    ),
                    box(title = "Prix",
                        status = "info",solidHeader = TRUE,collapsible = TRUE,width = 6,
                        sliderInput("range1", "Annees Debut-Fin:",2010 , 2019, value=c(2010,2019),width = 200),
                        plotlyOutput("plot4")
                    )


                  )
      ),


      tabItem(tabName = "local_import",

              selectInput(inputId = "dataset1",
                          label = "choisir la source:",
                          choices = c("local", "import")),
              plotlyOutput("local_import")
      ),
      tabItem(tabName = "listatt",
              radioButtons(inputId="dataset2", label="afficher selon :",
                           choices =c("Gouvernorat","Categorie"),width =800,selected = "Gouvernorat",

                           )
                                               ,


              plotlyOutput("liatt")
      )

  )


))

server <- function(input, output) {
  # Changing theme ----------------------------------------------------------
  callModule(module = serverChangeTheme, id = "moduleChangeTheme")

  output$table <- DT::renderDataTable(DT::datatable({
    data5<-data

    if (input$stat != "All") {
      data5 <- data5[data$Gouvernorat== input$stat,]
    }
    data5
  }))
  output$map <- renderLeaflet({



    map = getData(name = "GADM",
                  country = "TUN",
                  level = 1)

    map$NAME_1 %<>% as.factor()
    levels(map$NAME_1) <- levels(data$Gouvernorat)

    mapData <-
      table(data$Gouvernorat, data$Type) %>% as.data.frame() %>% dcast(Var1 ~ Var2, value.var = "Freq")
    colnames(mapData) = c("Gouvernorat", "Jour", "Nuit")

    mapData <-
      cbind.Spatial(map, mapData[match(toupper(map$NAME_1), mapData$Gouvernorat), ])


    leaflet(mapData) %>%
      addProviderTiles(providers$CartoDB.Positron) %>%
      addPolygons(
        fillColor = ~ colorNumeric("Reds", mapData@data[, 12] + mapData@data[, 13])(mapData@data[, 12] +
                                                                                      mapData@data[, 13]),
        fillOpacity = 10,
        col = "black",
        weight = 1.7,
        opacity = 1.7,
        highlight = highlightOptions(
          weight = 4.0,
          color = "#FFFFFF",
          fillOpacity = 0.7,
          bringToFront = TRUE
        ),
        label = sprintf(
          "<strong>%s</strong><br/>Jour: <b>%g</b><br/>Nuit: <b>%g</b>",
          mapData@data$NAME_1,
          mapData@data[, 12],
          mapData@data[, 13]
        ) %>% lapply(htmltools::HTML),
        labelOptions = labelOptions(
          style = list("font-weight" = "normal",
                       padding = "3px 8px"),
          textsize = "15px",
          direction = "auto"
        )
      ) %>%
      addLegend(
        pal =   colorNumeric("Reds", mapData@data[, 12] + mapData@data[, 13]),
        values = mapData@data[, 12] + mapData@data[, 13],
        opacity = 1.5,
        position = "bottomright",
        title = "Nombre total <br>des pharmacies"
      )
  })

  output$plot3 <- renderPlotly( {
    # check for the input variable

    plot_ly() %>%
      add_trace(Base_final1[c(input$range[1]:input$range[2])-2010,],x = ~Base_final1[c(input$range[1]:input$range[2])-2010,]$Annee,
                y = ~Base_final1[c(input$range[1]:input$range[2])-2010,]$Quantite_locale, type = 'bar', name='Local',
                textposition = 'auto',
                marker = list(color = 'rgb(100,124,105)')) %>%
      add_trace(Base_final1[c(input$range[1]:input$range[2])-2010,],x = ~Base_final1[c(input$range[1]:input$range[2])-2010,]$Annee,
                y = ~Base_final1[c(input$range[1]:input$range[2])-2010,]$Quantite_importee, type = 'bar', name='Importe',
                textposition = 'auto',
                marker = list(color = 'rgb(88, 140, 263)'
                )) %>%
      layout(title = "Histogrammes des Quantite Locale/importee",
             barmode = "group",
             xaxis = list(title = "Annee"),
             yaxis = list(title = "Quantite")
             ) })
   output$plot4<-renderPlotly({
     plot_ly() %>%
      add_trace(Base_final2[c(input$range1[1]:input$range1[2])-2010,],x = ~Base_final2[c(input$range1[1]:input$range1[2])-2010,]$Annee,
                y = ~Base_final2[c(input$range1[1]:input$range1[2])-2010,]$Prix_Quantite_locale, type = 'bar', name='Prix_Local',
                textposition = 'auto',
                marker = list(color = 'rgb(100,124,105)')) %>%
      add_trace(Base_final2[c(input$range1[1]:input$range1[2])-2010,],x = ~Base_final2[c(input$range1[1]:input$range1[2])-2010,]$Annee,
                y = ~Base_final2[c(input$range1[1]:input$range1[2])-2010,]$Prix_Quantite_importee, type = 'bar', name='Prix_Importe',
                textposition = 'auto',
                marker = list(color = 'rgb(88, 140, 263)'
                )) %>%
      layout(title = "Histogrammes des prix Local/importe",
             barmode = "group",
             xaxis = list(title = "Annee"),
             yaxis = list(title = "prix")
             )
  })


  output$plots <- renderPlotly(

 datasetInput() )


  output$local_import<- renderPlotly(

    switch(input$dataset1,
           "local" =return(x14),
           "import" = return(x15))
    )
  output$liatt <- renderPlotly({
      switch(input$dataset2,
                   "Gouvernorat" =p9 ,
                    "Categorie"=p10)

  })

  observe({
    if (input$quit == 1) stopApp()
  })
}


shinyApp(ui, server)
}
